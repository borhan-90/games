import pygame
import random
pygame.init()
# sakht safhe 
screen=pygame.display.set_mode((1002,500))
iconimg=pygame.image.load('dinoicon.png')
pygame.display.set_icon(iconimg)
pygame.display.set_caption('dino run')
#upload tasvir
dinoimg=pygame.image.load("dino.png")
enemy1=pygame.image.load("k1.png")
enemy2=pygame.image.load("k2.png")
enemy3=pygame.image.load("k3.png")
floorimg=pygame.image.load('floor.png')
enemy4=pygame.image.load('k4.png')
gameoversound=pygame.mixer.Sound('game over.mp3')
jumpsound=pygame.mixer.Sound('jump.mp3')

gameover=False
a=True
dinox=800
dinoy=250
dinojump=False
x=-1
enemyx=0
enemyy=270
enemyimg=pygame.image.load('k1.png')
score=0
enemylist=[enemy1,enemy2,enemy3]
speed=0.5
n=0
#rasm kardan
def dino (x,y):
    screen.blit(dinoimg,(x,y))
def enemy(x,y):
    if enemyimg==enemy4:
        y=100
    screen.blit(enemyimg,(x,y))
# baresi game over
def tasadof (x1,y1,x2,y2):
    if enemyimg==enemy4:
        y2=100
    a=(((x2-x1)**2)+((y2-y1)**2))**0.5
    if a<=50:
        return True
    else:
        return False
#score     
def point (x,y):
    font=pygame.font.Font('Vazirmatn-Bold.ttf',40)
    global score
    text=font.render('score:'+str(score//150),True,(0,0,0))
    screen.blit(text,(x,y))
#game over
def textgameover():
    font=pygame.font.Font('Vazirmatn-Bold.ttf',80)
    text_gameover=font.render('game over',True,(0,0,0))
    screen.blit(text_gameover,(300,100))
    
while a:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            a=False
            #jump
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and  not dinojump :
                dinojump=True
                jumpsound.play()
    if not gameover:
        #jump            
        if dinojump :
            dinoy+=speed*x
            if dinoy<=100:
                x=1
            
            if dinoy>=250:
                dinojump=False
                dinoy=250 
                x=-1
        #harekat enemy
        
        enemyx+=speed
            
        #enemy dobare
    
        if enemyx>=1000:
            enemyx=0
            enemyy=250
            enemyimg=random.choice(enemylist)    
     #score
        score+=1
    # enemy4
        if score//150 >=40:
            if enemy4 not in enemylist:
                enemylist.append(enemy4)
    #afzayesh sorat
        if score%600==0:
            speed+=0.1
        #safhe
        screen.fill((255,255,255))
        screen.blit(floorimg,(0,354))
        dino(dinox,dinoy)
        enemy(enemyx,enemyy)
        point(10,10)
        gameover=tasadof(dinox,dinoy,enemyx,enemyy)
        pygame.display.update()

    if gameover and n==0:
        textgameover()  
        gameoversound.play()
        n+=1
    
    pygame.display.update()