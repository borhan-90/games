
import pygame
import random
import time
pygame.init()

#safhe
screen=pygame.display.set_mode((600,600))
pygame.display.set_caption('memory')
icon=pygame.image.load('icon.png')
pygame.display.set_icon(icon)



#tasvir
ball=pygame.image.load('ball.png')
pencil=pygame.image.load('pencil.png')
house=pygame.image.load('house.png')
car=pygame.image.load('car.png')
motor=pygame.image.load('motor.png')
apple=pygame.image.load('apple.png')
lamp=pygame.image.load('lamp.png')
tree=pygame.image.load('tree.png')
back=pygame.image.load('back.png')
dorost=pygame.mixer.Sound('dorost.mp3')
eshtebah=pygame.mixer.Sound('eshtebah.mp3')
win=pygame.mixer.Sound('win.mp3')

            


list=[ball,ball,pencil,pencil,house,house,car,car,motor,motor,apple,apple,lamp,lamp,tree,tree]
newlist=[]
xlist=[125,245,365,485]
ylist=[150,250,350,450]
alphalist=16*[255]
dotalist=[]
dotanumlist=[]
alist=16*[True]
gameover=True
play=0
for i in range(4):
    for j in range(4):
        a=random.choice(list)
        list.remove(a)
        newlist.append(a)
        screen.blit(a,(xlist[i],ylist[j]))

        
    
    
    
    


run=True
while run:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        if event.type==pygame.MOUSEBUTTONDOWN:
            a,b=pygame.mouse.get_pos()
            if 189>=a>=125 and 214>=b>=150 and alist[0]:
                alphalist[0]=0
                dotalist.append(newlist[0])
                dotanumlist.append(0)
                alist[0]=False
            if 189>=a>=125 and 314>=b>=250 and alist[1]:
                alphalist[1]=0
                dotalist.append(newlist[1])
                dotanumlist.append(1)
                alist[1]=False
            if 189>=a>=125 and 414>=b>=350 and alist[2]:
                alphalist[2]=0
                dotalist.append(newlist[2])
                dotanumlist.append(2)
                alist[2]=False
            if 189>=a>=125 and 514>=b>=450 and alist[3]:
                alphalist[3]=0
                dotalist.append(newlist[3])
                dotanumlist.append(3)
                alist[3]=False
            if 309>=a>=245 and 214>=b>=150 and alist[4]:
                alphalist[4]=0
                dotalist.append(newlist[4])
                dotanumlist.append(4)
                alist[4]=False
            if 309>=a>=245 and 314>=b>=250 and alist[5]:
                alphalist[5]=0
                dotalist.append(newlist[5])
                dotanumlist.append(5)
                alist[5]=False
            if 309>=a>=245 and 414>=b>=350 and alist[6]:
                alphalist[6]=0
                dotalist.append(newlist[6])
                dotanumlist.append(6)
                alist[6]=False
            if 309>=a>=245 and 514>=b>=450 and alist[7]:
                alphalist[7]=0
                dotalist.append(newlist[7])
                dotanumlist.append(7)
                alist[7]=False
            if 429>=a>=365 and 214>=b>=150 and alist[8]:
                alphalist[8]=0
                dotalist.append(newlist[8])
                dotanumlist.append(8)
                alist[8]=False
            if 429>=a>=365 and 314>=b>=250 and alist[9]:
                alphalist[9]=0
                dotalist.append(newlist[9])
                dotanumlist.append(9)
                alist[9]=False
            if 429>=a>=365 and 414>=b>=350 and alist[10]:
                alphalist[10]=0
                dotalist.append(newlist[10])
                dotanumlist.append(10)
                alist[10]=False
            if 429>=a>=365 and 514>=b>=450 and alist[11]:
                alphalist[11]=0
                dotalist.append(newlist[11])
                dotanumlist.append(11)
                alist[11]=False
            if 549>=a>=485 and 214>=b>=150 and alist[12]:
                alphalist[12]=0
                dotalist.append(newlist[12])
                dotanumlist.append(12)
                alist[12]=False
            if 549>=a>=485 and 314>=b>=250 and alist[13]:
                alphalist[13]=0
                dotalist.append(newlist[13])
                dotanumlist.append(13)
                alist[13]=False
            if 549>=a>=485 and 414>=b>=350 and alist[14]:
                alphalist[14]=0
                dotalist.append(newlist[14])
                dotanumlist.append(14)
                alist[14]=False
            if 549>=a>=485 and 514>=b>=450 and alist[15]:
                alphalist[15]=0
                dotalist.append(newlist[15])
                dotanumlist.append(15)
                alist[15]=False

    if gameover:
        screen.fill((20,180,0))
        for i in range (4):
            for j in range(4):
                screen.blit(newlist[i*4+j],(xlist[i],ylist[j]))
                back.set_alpha(alphalist[i*4+j])
                screen.blit(back,(xlist[i],ylist[j]))
    pygame.display.update()

     
    if len(dotalist)==2:
        if dotalist[0] == dotalist[1]:
            dorost.play()
            dotalist.clear()
            dotanumlist.clear()
        else:
            eshtebah.play()
            time.sleep(1)
            alphalist[dotanumlist[0]]=255
            alphalist[dotanumlist[1]]=255
            alist[dotanumlist[0]]=True
            alist[dotanumlist[1]]=True
            dotalist.clear()
            dotanumlist.clear()
    
    n=0
    for i in range (16):
        if alphalist[i]==0:
            n+=1
    if n==16:
        if play<1:
            win.play()
        font=pygame.font.Font('vazirmatn-Bold.ttf',80)
        text=font.render('well done',True,(0,0,0))
        screen.blit(text,(150,30))
        gameover=False
        play+=1
        
    