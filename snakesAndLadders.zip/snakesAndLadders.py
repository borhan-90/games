import pygame
import random
import time
pygame.init()

screen=pygame.display.set_mode((735,800))
red=pygame.image.load('red.png')
blue=pygame.image.load('blue.png')
green=pygame.image.load('green.png')
yellow=pygame.image.load('yellow.png')
background=pygame.image.load('background.png')
tas1=pygame.image.load('1.png')
tas2=pygame.image.load('2.png')
tas3=pygame.image.load('3.png')
tas4=pygame.image.load('4.png')
tas5=pygame.image.load('5.png')
tas6=pygame.image.load('6.png')
redwin=pygame.image.load('redwin.png')
bluewin=pygame.image.load('bluewin.png')
greenwin=pygame.image.load('greenwin.png')
yellowwin=pygame.image.load('yellowwin.png')
tassound=pygame.mixer.Sound('tas.mp3')
marsound=pygame.mixer.Sound('mar.mp3')
pelesound=pygame.mixer.Sound('pele.mp3')
winsound=pygame.mixer.Sound('win.mp3')
icon=pygame.image.load('icon.png')
p1=pygame.image.load('p1.png')
p2=pygame.image.load('p2.png')
p3=pygame.image.load('p3.png')
p4=pygame.image.load('p4.png')
vs2=pygame.image.load('2vs2.png')
bywin=pygame.image.load('bywin.png')
rgwin=pygame.image.load('rgwin.png')
pygame.display.set_caption('snakes and ladders')
pygame.display.set_icon(icon)

bazikon=0
shoroo=True

redx=20
redy=640
rednum=0
bluex=20
bluey=675
bluenum=0
greenx=40
greeny=640
greennum=0
yellowx=40
yellowy=675
yellownum=0
m=0
bot=False
gameover=False

numplist=[rednum,bluenum,greennum,yellownum]
xlist=[redx,bluex,greenx,yellowx]
fxlist=[20,20,40,40]
fylist=[23.5,58.5,23.5,58.5]
ylist=[redy,bluey,greeny,yellowy]
tas=False
numlist=[tas1,tas2,tas3,tas4,tas5,tas6]
num=0
tas=False
turn=4
textbool=True
payanlist=[]

def payan ():
    global turn
    if numplist[0]==99:
        if 4 not in payanlist:
            payanlist.append(4)
    elif numplist[1]==99:
        if 1 not in payanlist:
            payanlist.append(1)
    elif numplist[2]==99:
        if 2 not in payanlist:
            payanlist.append(2)
    elif numplist[3]==99:
        if 3 not in payanlist:
            payanlist.append(3)
    
    if 1 in payanlist and turn==1:
        turn=2
    if 2 in payanlist and turn==2:
        turn=3
    if 3 in payanlist and turn==3:
        turn=4
    if 4 in payanlist and turn==4:
        turn=1


def emtehan (x,y,n,x2,y2,n2,x3,y3,n3,x4,y4,n4):
    global redx
    global redy
    global bluex
    global bluey
    global greenx
    global greeny
    global yellowx
    global yellowy
    global tas
    global textbool
    global rednum
    global bluenum
    global greennum
    global yellownum
    global turn
    
        
    if tas:
        if turn==1:
            for i in range(num):
                   
                if 8>=n%20>=0:
                    x+=68.5
                elif 18>=n%20>=10:
                    x-=68.5
                elif n %20==9 or n%20==19 :
                    y-=68.5
                n+=1
            if n<=99:
                xlist[0]=x
                ylist[0]=y
                numplist[0]=n
                
            
        elif turn==2:

            for i in range(num):
                  
                if 8>=n2%20>=0:
                    x2+=68.5
                elif 18>=n2%20>=10:
                    x2-=68.5
                elif n2 %20==9 or n2%20==19 :
                    y2-=68.5
                n2+=1
            if n2<=99:
                xlist[1]=x2
                ylist[1]=y2
                numplist[1]=n2
        elif turn==3:

            for i in range(num):
                
                if 8>=n3%20>=0:
                    x3+=68.5
                elif 18>=n3%20>=10:
                    x3-=68.5
                elif n3 %20==9 or n3%20==19 :
                    y3-=68.5
                n3+=1  
            if n3<=99:
                xlist[2]=x3
                ylist[2]=y3
                numplist[2]=n3
        elif turn==4:

            for i in range(num):
                  
                if 8>=n4%20>=0:
                    x4+=68.5
                elif 18>=n4%20>=10:
                    x4-=68.5
                elif n4%20==9 or n4%20==19 :
                    y4-=68.5
                n4+=1
            if n4<=99:
                xlist[3]=x4
                ylist[3]=y4
                numplist[3]=n4
                
        tas=False
        textbool=True

def draw (x1,y1,x2,y2,x3,y3,x4,y4):
    if shoroo:
        screen.fill((255,255,255))
        font=pygame.font.Font('vazirmatn-Bold.ttf',40)
        text=font.render('choose the game model',True,(0,0,0))
        screen.blit(text,(145,20))
        screen.blit(p1,(155,100))
        screen.blit(p2,(405,100))
        screen.blit(p3,(155,350))
        screen.blit(p4,(405,350))
        screen.blit(vs2,(280,600))
    else:
        screen.blit(background,(0,0))
        screen.blit(numlist[num-1],(25,735))
        screen.blit(red,(x1,y1))
        if 2<=bazikon:
            screen.blit(blue,(x2,y2))
        if 3<=bazikon:
            screen.blit(green,(x3,y3))
        if 4<=bazikon:
            screen.blit(yellow,(x4,y4))
    pygame.display.update()
    
def bordan():
    global gameover
    if bazikon==5:
        if numplist[1]==99 and numplist[3]==99:
            gameover=True
            winsound.play()
            screen.fill((255,255,255))
            time.sleep(1)
            screen.blit(bywin,(70,0))
        if numplist[0]==99 and numplist[2]==99:
            gameover=True
            winsound.play()
            screen.fill((255,255,255))
            time.sleep(1)
            screen.blit(rgwin,(70,0))
    else:
        if numplist[0]==99:
            gameover = True
            winsound.play()
            screen.fill((255,255,255))
            time.sleep(1)
            screen.blit(redwin,(70,0))
        if numplist[1]==99:
            gameover=True
            winsound.play()
            screen.fill((255,255,255))
            time.sleep(1)
            screen.blit(bluewin,(70,0))
        if numplist[2]==99:
            gameover=True
            winsound.play()
            screen.fill((255,255,255))
            time.sleep(1)
            screen.blit(greenwin,(70,0))
        if numplist[3]==99:
            gameover=True
            winsound.play()
            screen.fill((255,255,255))
            time.sleep(1)
            screen.blit(yellowwin,(70,0))
    pygame.display.update()
def turntext ():
    global textbool
    if not shoroo:
        if textbool:
            font=pygame.font.Font('vazirmatn-Bold.ttf',40)
            screen.fill((255,255,255))
            if turn==m:
                text=font.render('red turn',True,(255,0,0))
                screen.blit(text,(100,735))
            elif turn == 1 and 1<m<=4:
                text=font.render('blue turn',True,(0,0,255))
                screen.blit(text,(100,735))
            elif turn==2 and 2<m<=4:
                text=font.render('green turn',True,(0,255,0))
                screen.blit(text,(100,735))
            elif turn==3 and m==4:
                text=font.render('yellow turn',True,(255,200,0))
                screen.blit(text,(100,735))
            
def marpele():
        if numplist[turn-1]==6:
            xlist[turn-1]=4*68.5+fxlist[turn-1]
            ylist[turn-1]=6*68.5+fylist[turn-1]
            numplist[turn-1]=35
            pelesound.play()
            time.sleep(1)
            
        if numplist[turn-1]==20:
            xlist[turn-1]=2*68.5+fxlist[turn-1]
            ylist[turn-1]=4*68.5+fylist[turn-1]
            numplist[turn-1]=57
            pelesound.play()
            time.sleep(1)
        
        if numplist[turn-1]==30:
            xlist[turn-1]=9*68.5+fxlist[turn-1]
            ylist[turn-1]=4*68.5+fylist[turn-1]
            numplist[turn-1]=50
            pelesound.play()
            time.sleep(1)
        
        if numplist[turn-1]==33:
            xlist[turn-1]=3*68.5+fxlist[turn-1]
            ylist[turn-1]=68.5+fylist[turn-1]
            numplist[turn-1]=83
            pelesound.play()
            time.sleep(1)
        
        if numplist[turn-1]==53:
            xlist[turn-1]=8*68.5+fxlist[turn-1]
            ylist[turn-1]=68.5+fylist[turn-1]
            numplist[turn-1]=88
            pelesound.play()
            time.sleep(1)
        
        if numplist[turn-1]==62:
            xlist[turn-1]=68.5+fxlist[turn-1]
            ylist[turn-1]=68.5+fylist[turn-1]
            numplist[turn-1]=81
            pelesound.play()
            time.sleep(1)
        


        if numplist[turn-1]==32:
            xlist[turn-1]=4*68.5+fxlist[turn-1]
            ylist[turn-1]=9*68.5+fylist[turn-1]
            numplist[turn-1]=4
            marsound.play()
            time.sleep(1)
        
        if numplist[turn-1]==42:
            xlist[turn-1]=3*68.5+fxlist[turn-1]
            ylist[turn-1]=7*68.5+fylist[turn-1]
            numplist[turn-1]=23
            marsound.play()
            time.sleep(1)
        
        if numplist[turn-1]==55:
            xlist[turn-1]=fxlist[turn-1]
            ylist[turn-1]=8*68.5+fylist[turn-1]
            numplist[turn-1]=19
            marsound.play()
            time.sleep(1)
        
        if numplist[turn-1]==65:
            xlist[turn-1]=8*68.5+fxlist[turn-1]
            ylist[turn-1]=8*68.5+fylist[turn-1]
            numplist[turn-1]=11
            marsound.play()
            time.sleep(1)
        
        if numplist[turn-1]==77:
            xlist[turn-1]=68.5+fxlist[turn-1]
            ylist[turn-1]=4*68.5+fylist[turn-1]
            numplist[turn-1]=58
            marsound.play()
            time.sleep(1)
        
        if numplist[turn-1]==95:
            xlist[turn-1]=8*68.5+fxlist[turn-1]
            ylist[turn-1]=2*68.5+fylist[turn-1]
            numplist[turn-1]=71
            marsound.play()
            time.sleep(1)
        
        
          

    
run=True                                                                                                                      
while run :
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        if shoroo:
            if event.type == pygame.MOUSEBUTTONUP:
                a,b=pygame.mouse.get_pos()
                if 264>=a>=100 and 260>=b>=100:
                    bazikon=2
                    bot=True
                    shoroo=False
                    screen.fill((255,255,255))      
                if 514>=a>=350 and 260>=b>=100:
                    bazikon=2
                    shoroo=False
                    screen.fill((255,255,255))
                if 264>=a>=100 and 510>=b>=350:
                    bazikon=3
                    shoroo=False
                    screen.fill((255,255,255))
                if 514>=a>=350 and 510>=b>=350:
                    bazikon=4
                    shoroo=False
                    screen.fill((255,255,255))
                if 389>=a>=225 and 860>=b>=600:
                    #bazikon=5
                    #shoroo=False
                    #screen.fill((255,255,255))
                    font=pygame.font.Font('vazirmatn-Bold.ttf',40)
                    text=font.render('coming soon',True,(0,0,0))
                    for i in range(2000):
                        screen.blit(text,(255,520))
                        pygame.display.update()

                 
        if not shoroo:
            if not bot:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and not tas:
                        turn+=1
                        m=bazikon
                        if bazikon==5:
                            m=4
                        if turn>m:
                            turn=1
                        tassound.play()
                        tas=True
                        num=random.randint(1,6)
                
            if bot and not tas:
                if turn==1:
                    time.sleep(1)
                    turn+=1
                    m=bazikon
                    if bazikon==5:
                        m=4
                    if turn>m:
                        turn=1
                    tassound.play()
                    tas=True
                    num=random.randint(1,6)
                else:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE and not tas:
                            turn+=1
                            m=bazikon
                            if bazikon==5:
                                m=4
                            if turn>m:
                                turn=1
                            tassound.play()
                            tas=True
                            num=random.randint(1,6)

    if not gameover:
        if bazikon==5:
            payan()
        emtehan(xlist[0],ylist[0],numplist[0],xlist[1],ylist[1],numplist[1],xlist[2],ylist[2],numplist[2],xlist[3],ylist[3],numplist[3])
        turntext()
        draw(xlist[0],ylist[0],xlist[1],ylist[1],xlist[2],ylist[2],xlist[3],ylist[3])
        marpele()
        draw(xlist[0],ylist[0],xlist[1],ylist[1],xlist[2],ylist[2],xlist[3],ylist[3])
        bordan()